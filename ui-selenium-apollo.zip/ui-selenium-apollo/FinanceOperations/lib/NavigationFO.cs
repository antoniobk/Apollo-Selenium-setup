using OpenQA.Selenium;
using Apollo.General;

namespace Apollo.FinanceOperations.lib
{
    public class NavigationFO: Components
    {
        public IWebDriver driver;

        public NavigationFO(IWebDriver driver) : base(driver)
        {
            this.driver = driver;
        }


        public void navigateFOModulesMenu(String titleParentMenu, String titleChildMenu)
        {
            Console.WriteLine("navigateFOModulesMenu");
            Console.WriteLine("navigateFOModulesMenu: Opening modules menu");
            String xPathMenu = "//span[@data-dyn-title='Modules']";
            base.waitForElement(By.XPath(xPathMenu));
            driver.FindElement(By.XPath(xPathMenu)).Click();

            Console.WriteLine("navigateFOModulesMenu: Opening parent menu:" + titleParentMenu);
            String xPathTitleParentMenu = "//a[@data-dyn-title='" + titleParentMenu + "']";
            base.waitForElement(By.XPath(xPathTitleParentMenu));
            driver.FindElement(By.XPath(xPathTitleParentMenu)).Click();

            Console.WriteLine("navigateFOModulesMenu: Opening child menu:" + titleChildMenu);
            String xPathTitleChildMenu = "//a[@data-dyn-title='" + titleChildMenu + "']";
            base.waitForElement(By.XPath(xPathTitleChildMenu));
            driver.FindElement(By.XPath(xPathTitleChildMenu)).Click();
        }
    }
}