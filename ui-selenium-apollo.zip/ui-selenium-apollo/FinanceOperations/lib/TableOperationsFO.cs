using OpenQA.Selenium;
using Apollo.General;

namespace Apollo.FinanceOperations.lib
{
    public class TableOperationsFO : Components
    {
        public IWebDriver driver;
        private By searchValueElement;

        public TableOperationsFO(IWebDriver driver, By searchValueElement) : base(driver)
        {
            this.driver = driver;
            this.searchValueElement = searchValueElement;
        }

        public void searchTable(String searchValue)
        {
            Console.WriteLine("searchTable");
            base.waitForElement(searchValueElement);
            driver.FindElement(searchValueElement).SendKeys(searchValue);
            driver.FindElement(searchValueElement).SendKeys(Keys.Tab);
            driver.FindElement(By.XPath("//button[contains(@class, 'quickFilter-applyButton')]")).Click();
            driver.FindElement(searchValueElement).Clear();
            Thread.Sleep(3000);

        }

        public void selectFirstRow()
        {
            Console.WriteLine("selectFirstProductVersion");
            driver.FindElement(By.XPath("//div[@role='checkbox']")).Click();

            IList<IWebElement> checkboxes = driver.FindElements(By.XPath("//div[@role='checkbox']"));
            foreach (IWebElement checkbox in checkboxes)
            {
                Console.WriteLine("title = " + checkbox.GetAttribute("title"));
            }
        }

        public void selectAll()
        {
            Console.WriteLine("selectAll");
            base.waitForElement(searchValueElement);
            driver.FindElement(By.XPath("//div[@title='Alle rijen selecteren of de selectie opheffen']")).Click();
            Thread.Sleep(3000);
        }


        public void deleteElement()
        {
            Console.WriteLine("deleteElement");
            ErrorHandlingFO error = new ErrorHandlingFO(driver);
            driver.FindElement(By.Name("SystemDefinedDeleteButton")).Click();
            base.waitForElement(By.XPath("//div[@data-dyn-role='LightBox']"));
            driver.FindElement(By.Name("Yes")).Click();
            error.checkProcessDialogIsPresent();
            Thread.Sleep(3000);
        }

        public void checkNoResult()
        {
            Console.WriteLine("checkNoResult");
            ErrorHandlingFO error = new ErrorHandlingFO(driver);
            Boolean noResultExist = error.IsElementPresent(By.XPath("//div[contains(@class, 'dyn-noResultsMessage')]"));
            Assert.IsTrue(noResultExist, "checkNoResult: noResultExist is not visible");
        }


        public IList<IWebElement> getActiveElements()
        {
            Console.WriteLine("getActiveComponents: Search elements");
            IList<IWebElement> activeElements = driver.FindElements(By.XPath("//input[contains(@class, 'dyn-hyperlink')]"));
            foreach (IWebElement element in activeElements)
            {
                String text = element.GetAttribute("innerHTML");
                String id = element.GetAttribute("id");

                Console.WriteLine("getActiveComponents: id " + id);

            }

            return activeElements;
        }

    }
}