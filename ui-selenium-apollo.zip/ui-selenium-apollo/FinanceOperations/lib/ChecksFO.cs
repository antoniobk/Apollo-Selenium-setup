using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using Apollo.General;
using OpenQA.Selenium.Interactions;
using Apollo.FinanceOperations.lib;

namespace Apollo.FinanceOperations.lib
{
    public class ChecksFO
    {

        public IWebDriver driver;

        public ChecksFO(IWebDriver driver)
        {
            this.driver = driver;
        }


        public void checkIfContractExiststFO(string contractID)
        {
            LoginPage login = new LoginPage(driver);
            Components components = new Components(driver);
            Helpers helper = new Helpers(driver);
            Console.WriteLine("Checking if contract exists");
            driver.Navigate().GoToUrl("https://vab-apo-d365fo-tst01c4b0a58cacc80b05devaos.axcloud.dynamics.com/?cmp=vab&mi=VABContracts");
            login.LoginFO(driver);
            components.waitForElement(By.XPath("//input[@aria-label='Filteren']"));
            driver.FindElement(By.XPath("//input[@aria-label='Filteren']")).SendKeys(contractID);
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//input[@aria-label='Filteren']")).SendKeys(Keys.Return);
            Thread.Sleep(5000);
            //checks on radio button if contract is present
            helper.elementDisplayedCheck("//div[@role='checkbox']");

        }

        public void checkOGMnumber(string ogmNumber)
        {

            LoginPage login = new LoginPage(driver);
            Components components = new Components(driver);
            Helpers helper = new Helpers(driver);
            Console.WriteLine("Checking if ogm number exists");
            driver.Navigate().GoToUrl("https://vab-apo-d365fo-tst01c4b0a58cacc80b05devaos.axcloud.dynamics.com/?cmp=vab&mi=VABPaymentInfo");
            login.LoginFO(driver);
            components.waitForElement(By.XPath("//input[@aria-label='Filteren']"));
            driver.FindElement(By.XPath("//input[@aria-label='Filteren']")).SendKeys(ogmNumber);
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//input[@aria-label='Filteren']")).SendKeys(Keys.Return);
            Thread.Sleep(5000);
            //checks on radio button if contract is present
            helper.elementDisplayedCheck("//div[@role='checkbox']");
        }


        public void checkIfContractExistsPP(string contractID)
        {

            LoginPage login = new LoginPage(driver);
            Components components = new Components(driver);
            Helpers helper = new Helpers(driver);
            Console.WriteLine("Checking if contract exists");
            driver.Navigate().GoToUrl("https://vab-tst.crm4.dynamics.com/main.aspx?appid=f9797e2d-29c9-ec11-a7b5-0022487f49a6&pagetype=entitylist&etn=vab_contract&viewid=d89b4a72-20b4-ec11-983f-00224883c1fa&viewType=1039");
            login.LoginFO(driver);
            components.waitForElement(By.XPath("//input[@aria-label='Contract Filter by keyword']"));
            driver.FindElement(By.XPath("//input[@aria-label='Contract Filter by keyword']")).SendKeys(contractID);
            driver.FindElement(By.XPath("//input[@aria-label='Contract Filter by keyword']")).SendKeys(Keys.Return);
            Thread.Sleep(5000);
            helper.elementDisplayedCheck("/html/body/div[2]/div/div[4]/div[2]/div/div[1]/div/div/div[2]/div/section/div[3]/div/div/div/div/div[1]/div/div/div/div/div[2]/div[2]/div[3]/div[2]/div/div/div/div[1]/div/span");

        }

    }

}
