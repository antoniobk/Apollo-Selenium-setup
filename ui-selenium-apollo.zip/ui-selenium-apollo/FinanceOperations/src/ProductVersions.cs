using OpenQA.Selenium;
using Apollo.FinanceOperations.lib;
using Apollo.General;

namespace Apollo.FinanceOperations.src
{
    public class ProductVersions : Components
    {
        private IWebDriver driver;
        private String dateFormat = "MM/dd/yyyy";
        private TableOperationsFO table;

        public ProductVersions(IWebDriver driver) : base(driver)
        {
            this.driver = driver;
            this.table = new TableOperationsFO(driver, By.Name("ProdVersionGridQuickFilter_Input"));
        }
        public void createNewProductVersion(String productCode, String type)
        {
            Console.WriteLine("createNewProductVersion");
            ErrorHandlingFO error = new ErrorHandlingFO(driver);
            DateTime thisDay = DateTime.Today;

            Console.WriteLine("createNewProductVersion: Click button create New Product");
            base.waitForElement(By.Name("SystemDefinedNewButton"));
            driver.FindElement(By.Name("SystemDefinedNewButton")).Click();

            Console.WriteLine("createNewProductVersion: Fill in productcode");
            base.waitForElement(By.Name("ProductVersionGroup_ProductCode"));
            driver.FindElement(By.Name("ProductVersionGroup_ProductCode")).SendKeys(productCode);

            Console.WriteLine("createNewProductVersion: Select producttype");
            base.waitForElement(By.Name("ProductVersionGroup_ProductType"));
            base.selectElement(By.Name("ProductVersionGroup_ProductType"), type);

            Console.WriteLine("createNewProductVersion: Fill in productname");
            driver.FindElement(By.Name("ProductVersionGroup_ProductName")).SendKeys("Dit is een automatische test");

            Console.WriteLine("createNewProductVersionPackage: Fill in startdate");
            base.selectDateByName("ProductVersionGroup_ValidFrom", thisDay.ToString(dateFormat));

            Console.WriteLine("createNewProductVersionPackage: Fill in enddate");
            base.selectDateByName("ProductVersionGroup_ValidTo", "12/12/2099");

            if (type.Equals("Hoofdwaarborg") || type.Equals("Onderwaarborg"))
            {

                Console.WriteLine("createNewProductVersion: Fill in aankoopeenheid");
                driver.FindElement(By.Name("ReleasedProductGroup_PurchUnit")).SendKeys("Dag");
                Thread.Sleep(3000);

                Console.WriteLine("createNewProductVersion: Fill in verkoopprijs");
                driver.FindElement(By.Name("ReleasedProductGroup_SalesUnit")).SendKeys("Dag");
                Thread.Sleep(3000);
            }

            Console.WriteLine("createNewProductVersion: Confirm Product");
            driver.FindElement(By.Name("OK")).Click();
            error.checkErrorHandling();

            Console.WriteLine("createNewProductVersion: Check if productversion is created");
            searchProductVersion(productCode);

            Boolean rowExist = error.IsElementPresent(By.XPath("//input[contains(@value, '" + productCode + "')]"));
            Assert.IsTrue(rowExist, "createProductVersions: Productversion isn't correctly created or visible");
        }
        public void searchProductVersion(String productCode)
        {
            Console.WriteLine("searchProductVersion");
            table.searchTable(productCode);
            driver.FindElement(By.Name("ProdVersionGridQuickFilter_Input")).Clear();
            Thread.Sleep(3000);

        }

        public void selectFirstProductVersion()
        {
            Console.WriteLine("selectFirstProductVersion");
            driver.FindElement(By.XPath("//div[@role='checkbox']")).Click();

            IList<IWebElement> checkboxes = driver.FindElements(By.XPath("//div[@role='checkbox']"));
            foreach (IWebElement checkbox in checkboxes)
            {
                Console.WriteLine("title = " + checkbox.GetAttribute("title"));
            }
        }

        public void deleteProductVersion(String productCode)
        {
            Console.WriteLine("deleteProductVersion");
            selectFirstProductVersion();
            table.deleteElement();
            Thread.Sleep(3000);
            searchProductVersion(productCode);
            table.checkNoResult();
        }

    }
}