using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using Apollo.FinanceOperations.lib;
using Apollo.FinanceOperations.src;
using Apollo.General;

namespace Apollo.FinanceOperations.tests
{
    public class TestProductAssemblies
    {
        IWebDriver driver;
        ProductAssemblies productAssembly;

        [OneTimeSetUp]
        public void Setup()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("--incognito");
            options.AddArgument("--start-maximized");
            driver = new ChromeDriver(options);
        }

        [OneTimeSetUp]
        public void LoginFO()
        {
            LoginPage login = new LoginPage(driver);
            NavigationFO navigation = new NavigationFO(driver);
            productAssembly = new ProductAssemblies(driver);

            driver.Navigate().GoToUrl(login.getURLFO());
            login.LoginFO(driver);
            navigation.navigateFOModulesMenu("Contractbeheer", "Product Verkoopkanalen");
        }

        [Test]
        public void createProductAssembly()
        {
            String productCode="SeleniumAssemblyHWB";
            String[] productAssemblies = {"Digitaal","Personal Sales","Reissector","Retail","Verzekeringssector"};
            Assert.Multiple(() =>
          {
            
             for (int i = 0; i < productAssemblies.Length; i++)
             {
              productAssembly.createNewProductAssembly(productCode,productAssemblies[i]);
              productAssembly.deleteProductAssembly();
             }
          });
        }


        [OneTimeTearDown]
        public void Close()
        {
            //  driver.Quit();
        }

    }
}