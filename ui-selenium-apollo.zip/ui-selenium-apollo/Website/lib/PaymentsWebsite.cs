using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using Apollo.General;
using OpenQA.Selenium.Interactions;
using Apollo.FinanceOperations.lib;

namespace Apollo.Website.Payments;

public class PaymentsWebsite

{

    public IWebDriver driver;

    public PaymentsWebsite(IWebDriver driver)
    {
        this.driver = driver;
    }

    public string ogmNumber;
   

    public void KBCPayment()
    {
        Components components = new Components(driver);
        
        Thread.Sleep(10000);
        driver.Navigate().Refresh();
        components.waitForElement(By.Name("KBC Online_paymeth"));
        Thread.Sleep(2000);
        driver.FindElement(By.Name("KBC Online_paymeth")).Click();
        components.waitForElement(By.Id("ACS"));
        driver.FindElement(By.Name("submit"));
        components.waitForElement(By.Id("ACS"));
        components.waitForElement(By.Id("FirstName"));
        ogmNumber = driver.FindElement(By.Id("orderid")).Text;

    }
}