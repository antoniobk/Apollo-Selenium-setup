using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using Apollo.General;
using OpenQA.Selenium.Interactions;
using Apollo.FinanceOperations.lib;
using Apollo.Website.Payments;

namespace Apollo.Website.Users;

public class Users

{

    public IWebDriver driver;

    public Users(IWebDriver driver)
    {
        this.driver = driver;
    }

}
