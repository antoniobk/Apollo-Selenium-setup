using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using Apollo.General;
using OpenQA.Selenium.Interactions;
using Apollo.FinanceOperations.lib;
using Apollo.Website.Payments;

namespace Apollo.Website.Products;

public class Products

{

    public IWebDriver driver;

    public Products(IWebDriver driver)
    {
        this.driver = driver;
    }


    public void selectProduct(string product)
    {


        Random random = new Random();
        Components components = new Components(driver);
        Helpers helpers = new Helpers(driver);
        Actions action = new Actions(driver);
        LoginPage login = new LoginPage(driver);
        PaymentsWebsite payment = new PaymentsWebsite(driver);
        string dtime = DateTime.Now.ToString("yyyyMMddHHmmss");
        helpers.hoverOverElement("//*[contains(text(), 'Pechverhelping & reisverzekering')]");
        Thread.Sleep(5000);

        driver.FindElement(By.XPath(product)).Click();
        components.waitForElement(By.XPath("/html/body/section[2]/app-root/div/app-funnel/app-funnel-detail/app-funnel-header/div[2]/app-calculator/div[1]/div/div[2]/div[1]/span/strong"));
        string basePrice = "€ 149";
        string calculatorPrice = driver.FindElement(By.XPath("//strong[@class='ng-tns-c59-0']")).Text;
        Assert.AreEqual(basePrice, calculatorPrice);
        driver.FindElement(By.XPath("//*[@id='Dynamicdata.Wbmatrix[1].Io[1].Questions[1].Question']")).SendKeys("1wmm879");


        driver.FindElement(By.XPath("//*[contains(text(), 'Vervangwagen - Benelux - jaar')]")).Click();
        Thread.Sleep(3000);
        string calculatorPriceWithVervangwagen = "€ 217,99";
        string actualcalculatorPriceWithVervangwagen = driver.FindElement(By.XPath("//strong[@class='ng-tns-c59-0']")).Text;
        Thread.Sleep(3000);
        Assert.AreEqual(calculatorPriceWithVervangwagen, actualcalculatorPriceWithVervangwagen);
        driver.FindElement(By.XPath("//*[contains(text(), 'Volgende stap')]")).Click();
        components.waitForElement(By.XPath("//*[contains(text(), 'Reeds bestaande klant? Aanmelden:')]"));



    }


    public void CheckboxesTermsAndConditions(String elementXpath)
    {
        Random random = new Random();

        //identify elements and store it in list
        List<IWebElement> elementList = new List<IWebElement>();
        elementList.AddRange(driver.FindElements(By.ClassName(elementXpath)));
        //checking element count in list
        foreach (var item in elementList)
        {
            item.Click();
            
        }
        Thread.Sleep(2000);
        driver.FindElement(By.XPath("//*[contains(text(), 'Verleng met domiciliëring')]")).Click();
        driver.FindElement(By.XPath("//*[contains(text(), 'Ja, dit wens ik')]")).Click();
        
    }


}