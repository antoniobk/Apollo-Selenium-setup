using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using Apollo.General;
using OpenQA.Selenium.Interactions;
using Apollo.FinanceOperations.lib;
using Apollo.Website.lib;
using Apollo.Website.Products;
using Apollo.Website.Payments;
using Apollo.Website.Users;

namespace Apollo.PowerPlatform.tests
{
    public class PechverhelpingJaar
    {
        IWebDriver driver;



        [OneTimeSetUp]
        public void Setup()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("--incognito");
            options.AddArgument("--start-maximized");
            driver = new ChromeDriver(options);
        }


        [Test]
        public void SellProduct()
        {
            Random random = new Random();
            Components components = new Components(driver);
            Helpers helpers = new Helpers(driver);
            Actions action = new Actions(driver);
            LoginPage login = new LoginPage(driver);
            Products product = new Products(driver);
            PaymentsWebsite payment = new PaymentsWebsite(driver);
            ChecksFO checksfo = new ChecksFO(driver);
            Users users = new Users(driver);

            driver.Navigate().GoToUrl("https://tst-apo.vab.be/");

            product.selectProduct("//a[@gtmlabel='Pechbijstand']");
            users.RegisterUserInfoPechBijstandJaar();
            product.CheckboxesTermsAndConditions("vab__input__checkbox");
            payment.KBCPayment();
            checksfo.checkOGMnumber(payment.ogmNumber);
    }
}

}