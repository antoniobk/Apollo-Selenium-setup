using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using Apollo.General;
using Apollo.PowerPlatform.lib;


namespace Apollo.PowerPlatform.tests
{
    public class TestCreateB2C
    {
        IWebDriver driver;

        [OneTimeSetUp]
        public void Setup()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("--incognito");
            options.AddArgument("--start-maximized");
            driver = new ChromeDriver(options);
        }


        [Test]
        public void CreateB2C()
        {

            Random random = new Random();
            LoginPage login = new LoginPage(driver);
            NavigationPP navigation = new NavigationPP(driver); ;

            Components components = new Components(driver);
            Helpers helpers = new Helpers(driver);
            ChecksPP checkspp = new ChecksPP(driver);



            driver.Navigate().GoToUrl("https://vab-tst.crm4.dynamics.com/main.aspx?appid=f9797e2d-29c9-ec11-a7b5-0022487f49a6&pagetype=dashboard&id=78275f7d-9282-ec11-8d21-6045bd8f77fd&type=system&_canOverride=true");
            login.Login(driver);
            navigation.navigatePPMenu("Customer Management");
            driver.FindElement(By.XPath("//*[contains(text(),'Customer Management')]")).Click();
            Thread.Sleep(5000);

            Console.WriteLine("Clicking on Create B2C customer");
            helpers.elementDisplayedCheck("//div[@data-control-name='btnCreateB2C']");
            driver.FindElement(By.XPath("//div[@data-control-name='btnCreateB2C']")).Click();
            Thread.Sleep(5000);

            Console.WriteLine("Entering user info");
            driver.FindElement(By.XPath("//input[@aria-label='First Name']")).SendKeys("FirstName");
            driver.FindElement(By.XPath("//input[@aria-label='Last Name']")).SendKeys("LastName");
            driver.FindElement(By.XPath("//input[@aria-label='Sparta Contact ID']")).SendKeys("Sparta Contact ID");
            driver.FindElement(By.XPath("//input[@aria-label='Email']")).SendKeys("Email");

            //select gender dropdown
            Console.WriteLine("Selecting gender");
            driver.FindElement(By.XPath("//div[@aria-label='Gender. Required.']")).Click();
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//*[contains(text(),'Male')]")).Click();

            //select language dropdown
            Console.WriteLine("Selecting language");
            driver.FindElement(By.XPath("//div[@aria-label='Language. Required.']")).Click();
            driver.FindElement(By.XPath("//*[contains(text(),'Dutch')]")).Click();

            driver.FindElement(By.XPath("//input[@aria-label='Mobile Phone']")).SendKeys("0474951914");
            driver.FindElement(By.XPath("//input[@aria-label='Address 1: Phone']")).SendKeys("032970605");

            //add address with Road65
            Console.WriteLine("Selecting address with R65");
            driver.FindElement(By.XPath("//div[@data-control-name='btnVoegAdresB2C']")).Click();
            Thread.Sleep(8000);
            driver.FindElement(By.XPath("//input[@placeholder='Postcode']")).SendKeys("2030");
            Thread.Sleep(8000);
            driver.FindElement(By.XPath("//div[@data-control-name='AVPostBoxB2C']")).Click();
            Thread.Sleep(8000);
            driver.FindElement(By.XPath("//*[@id='pac-combobox-1-list0']")).Click();
            Thread.Sleep(8000);
            driver.FindElement(By.XPath("//i[@style='font-family: FabricMDL2Icons;']")).Click();
            Thread.Sleep(8000);
            driver.FindElement(By.XPath("//*[contains(text(),'Albertkanaal')]")).Click();
            Thread.Sleep(8000);
            driver.FindElement(By.XPath("//div[@data-control-name='btnAVOKB2C']")).Click();
            Thread.Sleep(8000);


            //contract communication format
            Console.WriteLine("Selecting communication format");
            driver.FindElement(By.XPath("//div[@aria-label='Contract Communications Format. Required.']")).Click();
            driver.FindElement(By.XPath("//*[contains(text(),'Paper')]")).Click();

            //birtday
            Console.WriteLine("Selecting birtdate");
            driver.FindElement(By.XPath("//input[@aria-label='Birthday. Required.']")).SendKeys("11/22/1995");

            int randomBankAccountNumber = random.Next(1, 999999999);
            int houseNumber = random.Next(1, 100);

            driver.FindElement(By.XPath("//input[@aria-label='IBAN']")).SendKeys($"BE{randomBankAccountNumber.ToString()}");
            driver.FindElement(By.XPath("//input[@aria-label='House Number']")).SendKeys(houseNumber.ToString());


            //click create
            Console.WriteLine("Save contact");
            driver.FindElement(By.XPath("/html/body/div[3]/div/div[4]/div[2]/div/div[1]/div/div/div/div/div/div/div[3]/div/div/div[1]/div/div/div/div/div[1]/div/div/div/div/div/div[3]/div/div/div/button/span")).Click();

        }

        



        [OneTimeTearDown]
        public void Close()
        {
            // driver.Quit();
        }

    }
}