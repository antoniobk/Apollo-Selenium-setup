using OpenQA.Selenium;
using Apollo.General;

namespace Apollo.PowerPlatform.lib
{
    public class ChecksPP
    {

        public IWebDriver driver;

        public ChecksPP(IWebDriver driver)
        {
            this.driver = driver;
        }

    }

}


