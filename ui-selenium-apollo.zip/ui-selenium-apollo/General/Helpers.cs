using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using Apollo.Website.Products;


namespace Apollo.General;

public class Helpers
{

    public IWebDriver driver;

    public Helpers(IWebDriver driver)
    {
        this.driver = driver;
    }


    public void hoverOverElement(String element)
    {

        Actions actions = new Actions(driver);

        actions.MoveToElement(driver.FindElement(By.XPath(element)));
        actions.Perform();
    }

    public void elementDisplayedCheck(String elementXpath)
    {
        //identify elements and store it in list
        List<IWebElement> elementList = new List<IWebElement>();
        elementList.AddRange(driver.FindElements(By.XPath(elementXpath)));
        //checking element count in list
        if (elementList.Count > 0)
        {
            Console.WriteLine("----------------------Element is Present-----------------------");
            Console.WriteLine(elementList.Count());
        }
        else
        {
            Console.WriteLine("----------------------Element is not Present-------------------");
            Assert.Fail();
        }
    }



}