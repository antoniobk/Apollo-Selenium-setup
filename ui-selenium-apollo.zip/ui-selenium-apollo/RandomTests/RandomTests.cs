using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using Apollo.General;
using OpenQA.Selenium.Interactions;
using Apollo.FinanceOperations.lib;
using Apollo.Website.Products;
using Apollo.Website.Payments;

namespace Apollo.PowerPlatform.tests
{
    public class RandomTests
    {
        IWebDriver driver;



        [OneTimeSetUp]
        public void Setup()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("--incognito");
            options.AddArgument("--start-maximized");
            driver = new ChromeDriver(options);
        }


        [Test]
        public void Test()
        {
            Random random = new Random();
            Components components = new Components(driver);
            Helpers helpers = new Helpers(driver);
            Actions action = new Actions(driver);
            LoginPage login = new LoginPage(driver);
            ChecksFO checksfo = new ChecksFO(driver);
            Products product = new Products(driver);
            PaymentsWebsite payment = new PaymentsWebsite(driver);


            driver.Navigate().GoToUrl("https://acc-apo.vab.be/");
            components.waitForElement(By.XPath("//a[@gtmlabel='Mijn_VAB']"));
            Console.WriteLine(payment.ogmNumber);


        }
    }
}